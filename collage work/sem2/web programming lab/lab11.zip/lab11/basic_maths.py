import math

def round1(value):
    return round(value, 3)

def floor1(value):
    return math.floor(value)

def ceil1(value):
    return math.ceil(value)

def hello(user):
    print(f"Hello, {user}!")

def pi1():
    return math.pi