#include <stdio.h>
#include "stack.h"

int main()
{
    Stack s;
    create(&s);

    Push(&s, 10);
    Push(&s, 20);
    Push(&s, 30);
    Push(&s, 40);
    Push(&s, 50);
    Push(&s, 60);
    Push(&s, 70);
    Push(&s, 80);
    Push(&s, 90);
    Push(&s, 100);
    Display(&s);
}