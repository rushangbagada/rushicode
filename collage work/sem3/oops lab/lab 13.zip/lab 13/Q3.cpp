// Q3: Mini Bank Statement Generator
// Demonstrates: fixed, setprecision, setw, currency formatting

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main() {
    string name, accountNumber;
    double balance;
    
    cout << "=== Bank Statement Generator ===\n\n";
    
    cout << "Enter Customer Name: ";
    cin.ignore();
    getline(cin, name);
    
    cout << "Enter Account Number: ";
    getline(cin, accountNumber);
    
    cout << "Enter Balance Amount: ";
    cin >> balance;
    
    // Display Mini Statement
    cout << "\n\n";
    cout << string(60, '=') << endl;
    cout << setw(35) << "MINI BANK STATEMENT" << endl;
    cout << string(60, '=') << endl;
    
    cout << left << setw(20) << "Customer Name:" 
         << setw(40) << name << endl;
    
    cout << left << setw(20) << "Account Number:" 
         << setw(40) << accountNumber << endl;
    
    cout << string(60, '-') << endl;
    
    cout << left << setw(20) << "Current Balance:" 
         << right << "₹ " << fixed << setprecision(2) 
         << setw(15) << balance << endl;
    
    cout << string(60, '=') << endl;
    
    // Additional transaction display
    cout << "\n" << left << setw(30) << "Transaction Type" 
         << right << setw(30) << "Amount (₹)" << endl;
    cout << string(60, '-') << endl;
    
    cout << left << setw(30) << "Opening Balance" 
         << right << "₹ " << fixed << setprecision(2) 
         << setw(15) << balance << endl;
    
    cout << left << setw(30) << "Interest Credited" 
         << right << "₹ " << fixed << setprecision(2) 
         << setw(15) << (balance * 0.04) << endl;
    
    double closingBalance = balance + (balance * 0.04);
    cout << string(60, '-') << endl;
    cout << left << setw(30) << "Closing Balance" 
         << right << "₹ " << fixed << setprecision(2) 
         << setw(15) << closingBalance << endl;
    
    cout << string(60, '=') << endl;
    cout << "\nThank you for banking with us!\n";
    
    return 0;
}
